﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HAFTA5__ARABA_GALERİSİ
{
    public class araba
    {
        public string marka;
        public string model;
        public string renk;

        public araba(string marka, string model, string renk)
        {
            this.marka = marka;
            this.model = model;
            this.renk = renk;
        }
    }
}
