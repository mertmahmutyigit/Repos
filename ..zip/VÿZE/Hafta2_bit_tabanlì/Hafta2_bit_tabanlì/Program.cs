﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hafta2_bit_tabanlı
{
    internal class Program
    {
        static void Main(string[] args)
        {
            byte b1 = 254;
            byte b2 = (byte)~b1;
            Console.WriteLine(b2);
            Console.ReadLine();
        }<<z+ 
    }
}
