﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace static_kurucular
{

   abstract class sınıf
    {   public sınıf() { int a = 5}
        public abstract void a();
    }
    public class b: sınıf{int c=10}
    public override a() { int c = 0; }
    internal class Program
    {
        static void Main(string[] args)
        {


        }
    }
}
