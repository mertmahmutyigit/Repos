﻿namespace RootsCalculation
{
    internal class Polynomial
    {
        private Complex[] complexes;

        public Polynomial(Complex[] complexes)
        {
            this.complexes = complexes;
        }
    }
}