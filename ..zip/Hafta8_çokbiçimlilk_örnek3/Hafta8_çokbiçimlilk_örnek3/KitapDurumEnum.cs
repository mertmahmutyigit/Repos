﻿namespace Hafta8_çokbiçimlilk_örnek3
{
    internal class KitapDurumEnum
    {
        public static KitapDurumEnum YAYINLANDI { get; internal set; }
        public static KitapDurumEnum INCELEMEDE { get; internal set; }
        public static KitapDurumEnum REDDEDILDI { get; internal set; }
    }
}