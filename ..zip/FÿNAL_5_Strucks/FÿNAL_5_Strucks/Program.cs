﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FİNAL_5_Strucks
{
    public class d
    {
struct ögr
        {
            int no;
            string ad;
            string soyad;
        public ögr(int no,string ad,string soyad) { 
                this.no = no;
                this.ad = ad;   
                this.soyad = soyad;
        }
        }
    }
    internal class Program
    {
        
        
        static void Main(string[] args)
        { 
            
            Console.WriteLine();

        }
    }
}
