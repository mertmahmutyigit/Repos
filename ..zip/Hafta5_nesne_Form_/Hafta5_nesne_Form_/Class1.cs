﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hafta5_nesne_Form_
{
    internal class Class1
    {
       public string ad;
       public string soyad;
    }
}
